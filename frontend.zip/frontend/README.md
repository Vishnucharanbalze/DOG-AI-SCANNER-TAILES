# Frontend
The website the user sees: plain HTML, CSS and JavaScript with no build step.

| File | Purpose |
|---|---|
| `index.html` | Upload page and results page |
| `styles.css` | Layout, colours and phone layout |
| `app.js` | Photo upload, drag-and-drop, calls `POST /api/scan`, shows results, downloads the report |
| `fonts/` | Bricolage Grotesque and Atkinson Hyperlegible (open-source fonts) |

The Java API in `backend/java-api` serves these files at http://localhost:8080.
