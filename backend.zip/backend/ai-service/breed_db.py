"""Loads the AKC breed records."""
import json
from pathlib import Path


class BreedDB:
    def __init__(self, data_dir: Path):
        self.breeds = json.loads((data_dir / "breeds.json").read_text(encoding="utf8"))

    def info(self, name: str) -> dict:
        return dict(self.breeds[name])
