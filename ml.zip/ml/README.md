# Machine learning
| Folder | Purpose |
|---|---|
| `notebook/` | `train_dog_scanner.ipynb`: run in Google Colab to train the breed model and measure its accuracy. Produces `dog_model.zip` for `backend/ai-service/model/`. |
| `data-tools/` | `build_breeds.py` builds `backend/ai-service/data/breeds.json` from AKC sources; `akc_standards_summary.txt` holds the AKC standard summaries; `make_notebook.py` regenerates the notebook. |
