@echo off
setlocal
cd /d "%~dp0"
title AI Dog Scanner
set "ROOT=%CD%"
set "MAVEN_VER=3.9.11"

echo.
echo Checking Python...
py -3.12 --version >nul 2>nul
if errorlevel 1 goto no_python

echo Checking Java...
where java >nul 2>nul
if errorlevel 1 goto no_java
java -version 2>&1 | findstr /r /c:"version \"1[7-9]" /c:"version \"[2-9][0-9]" >nul
if errorlevel 1 goto no_java

if exist "%ROOT%\backend\ai-service\.venv\Scripts\python.exe" goto have_venv
echo Setting up Python. This happens once.
py -3.12 -m venv "%ROOT%\backend\ai-service\.venv"
if errorlevel 1 goto failed
:have_venv

if exist "%ROOT%\backend\ai-service\.venv\installed.txt" goto have_packages
echo Installing the AI libraries. This happens once and can take 10 minutes.
"%ROOT%\backend\ai-service\.venv\Scripts\python.exe" -m pip install --upgrade pip
"%ROOT%\backend\ai-service\.venv\Scripts\python.exe" -m pip install -r "%ROOT%\backend\ai-service\requirements.txt"
if errorlevel 1 goto failed
echo done> "%ROOT%\backend\ai-service\.venv\installed.txt"
:have_packages

if exist "%ROOT%\.tools\maven\bin\mvn.cmd" goto have_maven
echo Downloading Maven, the Java build tool. This happens once.
if not exist "%ROOT%\.tools" mkdir "%ROOT%\.tools"
curl -fL -o "%ROOT%\.tools\maven.zip" "https://archive.apache.org/dist/maven/maven-3/%MAVEN_VER%/binaries/apache-maven-%MAVEN_VER%-bin.zip"
if errorlevel 1 goto failed
tar -xf "%ROOT%\.tools\maven.zip" -C "%ROOT%\.tools"
if errorlevel 1 goto failed
ren "%ROOT%\.tools\apache-maven-%MAVEN_VER%" maven
del "%ROOT%\.tools\maven.zip"
:have_maven

echo Starting the AI service and the website...
start "AI service (leave open)" /d "%ROOT%\backend\ai-service" cmd /k ""%ROOT%\backend\ai-service\.venv\Scripts\python.exe" -m uvicorn main:app --host 127.0.0.1 --port 8000"
start "Website (leave open)" /d "%ROOT%\backend\java-api" cmd /k ""%ROOT%\.tools\maven\bin\mvn.cmd" spring-boot:run"

echo Waiting for the website. The first start can take several minutes...
set /a tries=0
:wait
curl -s -o nul http://localhost:8080/
if not errorlevel 1 goto open
set /a tries+=1
if %tries% geq 200 goto slow
timeout /t 3 /nobreak >nul
goto wait

:open
start "" http://localhost:8080/
echo.
echo The site is open at http://localhost:8080
echo Leave the two other windows open while you use it. Close them to stop.
pause
exit /b 0

:slow
echo The website hasn't started yet. Look at the "Website" window for a red ERROR line.
pause
exit /b 1

:no_python
echo Python 3.12 was not found. Follow Part 1 of START-HERE.html, then run this again.
pause
exit /b 1

:no_java
echo Java 17 or later was not found. Follow Part 1 of START-HERE.html, then run this again.
pause
exit /b 1

:failed
echo Setup stopped because of the error above. Check your internet connection and run this again.
pause
exit /b 1
