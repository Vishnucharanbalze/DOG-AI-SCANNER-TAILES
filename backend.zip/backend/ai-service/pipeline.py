"""The scanning steps: check photo, find dog, classify breed, read coat, build result.

The result never contains a made-up value. When a step is not sure, it says so.
"""
import io
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from breed_db import BreedDB

DETECTOR_ID = "facebook/detr-resnet-50"
CLIP_ID = "openai/clip-vit-base-patch32"
OTHER = "other_dog"

SEX_RESULT = {
    "value": "Cannot determine from photograph",
    "note": "A normal photo can't reliably show a dog's biological sex, and this scanner has no tested model "
            "for it. A vet or the dog's records can confirm it.",
}
FAMILIES = {
    "Poodle": {"labels": ["Poodle (Toy)", "Poodle (Miniature)", "Poodle (Standard)"], "same_breed": True},
    "Schnauzer": {"labels": ["Miniature Schnauzer", "Standard Schnauzer", "Giant Schnauzer"], "same_breed": False},
}
COAT_PROMPTS = {
    "Short coat": "a photo of a dog with a short coat",
    "Medium coat": "a photo of a dog with a medium length coat",
    "Long coat": "a photo of a dog with a long flowing coat",
    "Double coat": "a photo of a dog with a thick fluffy double coat",
    "Curly coat": "a photo of a dog with a tightly curly coat",
    "Wavy coat": "a photo of a dog with a wavy coat",
    "Wire coat": "a photo of a dog with a rough wiry coat",
    "Smooth coat": "a photo of a dog with a sleek smooth coat",
    "Hairless": "a photo of a hairless dog with bare skin",
}
COLOUR_PROMPTS = {
    "Black": "a photo of a solid black dog", "White": "a photo of a solid white dog",
    "Brown or chocolate": "a photo of a solid brown chocolate dog", "Tan": "a photo of a tan dog",
    "Fawn": "a photo of a fawn colored dog", "Golden": "a photo of a golden yellow dog",
    "Cream": "a photo of a cream colored dog", "Red": "a photo of a reddish brown dog",
    "Gray or blue": "a photo of a gray blue dog", "Black and tan": "a photo of a black and tan dog",
    "Black and white": "a photo of a black and white dog", "Brown and white": "a photo of a brown and white dog",
    "Tricolor": "a photo of a tricolor dog with black, white and tan",
    "Brindle": "a photo of a brindle striped dog", "Merle": "a photo of a merle mottled dog",
    "Spotted or ticked": "a photo of a white dog with dark spots", "Sable": "a photo of a sable dog",
}
AGE_PROMPTS = {"puppy": "a photo of a young puppy", "adult": "a photo of a fully grown adult dog"}
SCORE_NOTE = ("Scores compare the breeds with each other. They are the model's relative output, "
              "not a guaranteed chance of being correct.")
DEFAULT_META = {"threshold_confident": 0.80, "threshold_likely": 0.50, "temperature": 1.0, "blur_threshold": 20.0}


class Rejected(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code, self.message = code, message


class Backends:
    """The three real AI models. Tests replace this with a stand-in."""

    def __init__(self, model_dir: Path, device: str = None):
        import torch
        from transformers import (AutoImageProcessor, AutoModelForImageClassification,
                                  AutoModelForObjectDetection, CLIPModel, CLIPProcessor)
        self.torch = torch
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.det_proc = AutoImageProcessor.from_pretrained(DETECTOR_ID)
        self.det = AutoModelForObjectDetection.from_pretrained(DETECTOR_ID).to(self.device).eval()
        self.clip_proc = CLIPProcessor.from_pretrained(CLIP_ID)
        self.clip = CLIPModel.from_pretrained(CLIP_ID).to(self.device).eval()
        path = str(model_dir / "classifier")
        self.cls_proc = AutoImageProcessor.from_pretrained(path)
        self.cls = AutoModelForImageClassification.from_pretrained(path).to(self.device).eval()

    def detect(self, img):
        """Returns [(label, score, (x0, y0, x1, y1)), ...]."""
        torch = self.torch
        inputs = self.det_proc(images=img, return_tensors="pt").to(self.device)
        with torch.inference_mode():
            out = self.det(**inputs)
        found = self.det_proc.post_process_object_detection(
            out, threshold=0.5, target_sizes=[(img.height, img.width)])[0]
        return [(self.det.config.id2label[int(l)], float(s), tuple(float(v) for v in b))
                for s, l, b in zip(found["scores"], found["labels"], found["boxes"])]

    def classify_logits(self, img):
        """Average logits over the photo and its mirror image."""
        torch = self.torch
        inputs = self.cls_proc(images=[img, ImageOps.mirror(img)], return_tensors="pt").to(self.device)
        with torch.inference_mode():
            return self.cls(**inputs).logits.mean(0).cpu().numpy()

    def clip_scores(self, img, prompts):
        torch = self.torch
        inputs = self.clip_proc(text=prompts, images=img, return_tensors="pt", padding=True).to(self.device)
        with torch.inference_mode():
            return self.clip(**inputs).logits_per_image.softmax(-1)[0].cpu().numpy()


def softmax(x):
    x = x - x.max()
    p = np.exp(x)
    return p / p.sum()


def sharpness(img):
    """Variance of the Laplacian. Low means blurry."""
    g = np.asarray(ImageOps.contain(img.convert("L"), (512, 512)), dtype=np.float32)
    lap = g[:-2, 1:-1] + g[2:, 1:-1] + g[1:-1, :-2] + g[1:-1, 2:] - 4 * g[1:-1, 1:-1]
    return float(lap.var())


def open_image(data: bytes):
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
        raise Rejected("bad_image", "This file isn't a readable photo. Upload a JPG, PNG or WebP image.")
    img = ImageOps.exif_transpose(img).convert("RGB")
    if min(img.size) < 100:
        raise Rejected("too_small", "This photo is too small. Use one at least 100 pixels wide and tall.")
    return img


def area(box):
    return max(0, box[2] - box[0]) * max(0, box[3] - box[1])


def choose_dog(detections, img):
    dogs = sorted([d for d in detections if d[0] == "dog" and d[1] >= 0.70], key=lambda d: -area(d[2]))
    warnings = []
    if not dogs:
        seen = {d[0] for d in detections if d[1] >= 0.70}
        if "dog" in {d[0] for d in detections}:
            raise Rejected("dog_unclear", "A dog might be in this photo, but it isn't clear enough to scan. "
                                          "Try a closer, brighter photo.")
        if "cat" in seen:
            raise Rejected("not_a_dog", "This looks like a cat. Upload a photo of a dog.")
        if "person" in seen:
            raise Rejected("not_a_dog", "This photo shows a person and no dog. Upload a photo of a dog.")
        raise Rejected("not_a_dog", "No dog was found in this photo. Upload a clear photo of one dog.")
    main = dogs[0]
    others = [d for d in dogs[1:] if area(d[2]) >= area(main[2]) * 0.15]
    if others:
        if area(main[2]) < area(others[0][2]) * 3:
            raise Rejected("multiple_dogs", f"This photo shows {len(others) + 1} dogs. Upload a photo with one dog, or crop it to one.")
        warnings.append("More than one dog is visible. These results are for the largest dog.")
    x0, y0, x1, y1 = main[2]
    pad_x, pad_y = (x1 - x0) * 0.08, (y1 - y0) * 0.08
    box = (max(0, int(x0 - pad_x)), max(0, int(y0 - pad_y)), min(img.width, int(x1 + pad_x)), min(img.height, int(y1 + pad_y)))
    return img.crop(box), warnings


def best_of(scores, names, floor):
    i = int(np.argmax(scores))
    top = float(scores[i])
    return names[i], top, top >= floor


class DogScanner:
    def __init__(self, data_dir: Path, model_dir: Path, backends=None):
        self.db = BreedDB(data_dir)
        self.labels = json.loads((data_dir / "labels.json").read_text(encoding="utf8"))
        meta_path = model_dir / "model_meta.json"
        self.meta = {**DEFAULT_META, **(json.loads(meta_path.read_text(encoding="utf8")) if meta_path.exists() else {})}
        if self.meta.get("labels") and self.meta["labels"] != self.labels:
            raise RuntimeError("The model's breed list doesn't match this app's breed list.")
        self.backends = backends or Backends(model_dir)

    def _reject(self, err):
        return {"status": "rejected", "code": err.code, "message": err.message}

    def scan(self, data: bytes) -> dict:
        try:
            return self._scan(data)
        except Rejected as err:
            return self._reject(err)

    def _breed_decision(self, probs):
        order = np.argsort(-probs)
        scores = {self.labels[i]: float(probs[i]) for i in range(len(probs))}
        top_label = self.labels[order[0]]
        family = next((k for k, v in FAMILIES.items() if top_label in v["labels"]), None)
        score = scores[top_label]
        share = 1.0
        if family:
            total = sum(scores[l] for l in FAMILIES[family]["labels"])
            share = score / total
            score = total
        return top_label, family, score, share, scores, order

    def _scan(self, data):
        img = open_image(data)
        b = self.backends
        crop, warnings = choose_dog(b.detect(img), img)
        if min(crop.size) < 80:
            raise Rejected("dog_too_small", "The dog is too small in this photo. Move closer or crop the photo around the dog.")

        grey = np.asarray(crop.convert("L"), dtype=np.float32)
        brightness = float(grey.mean())
        if brightness < 30:
            raise Rejected("too_dark", "This photo is too dark to read. Try one taken in better light.")
        if brightness > 240:
            raise Rejected("too_bright", "This photo is washed out by light. Try one without strong glare.")
        sharp = sharpness(crop)
        blur = float(self.meta["blur_threshold"])
        if sharp < blur:
            raise Rejected("too_blurry", "This photo is too blurry to identify a breed. Try a sharper one.")
        if sharp < blur * 2:
            warnings.append("This photo is a little soft, so the breed result is less dependable.")

        logits = b.classify_logits(crop) / float(self.meta["temperature"])
        probs = softmax(logits)
        top_label, family, score, share, scores, order = self._breed_decision(probs)

        if top_label == OTHER or score < float(self.meta["threshold_likely"]):
            verdict = "uncertain"
        elif score >= float(self.meta["threshold_confident"]):
            verdict = "confident"
        else:
            verdict = "likely"

        age_scores = b.clip_scores(crop, list(AGE_PROMPTS.values()))
        puppy = float(age_scores[0]) >= 0.65
        if puppy:
            warnings.append("This dog looks like a puppy. Breed results are less dependable for puppies, and it may not be full size yet.")

        top3 = []
        for i in order:
            label = self.labels[int(i)]
            if label == OTHER:
                continue
            top3.append({"name": label, "score": round(float(probs[int(i)]) * 100, 1)})
            if len(top3) == 3:
                break

        other_score = scores.get(OTHER, 0.0)
        mixed = verdict == "uncertain" and (top_label == OTHER or other_score >= 0.20 or self._groups_differ(top3))

        breed, headline, variety, size = None, "Breed unclear from this photo", None, None
        if verdict != "uncertain":
            breed = self.db.info(top_label)
            headline = top_label
            if family == "Poodle":
                headline = "Poodle"
            if family and share < 0.70:
                headline = "Poodle" if family == "Poodle" else "Schnauzer"
                warnings.append(f"The model can tell this is likely a {family}, but it can't settle which size from this photo.")
            variety = self._variety(top_label, family, share, puppy, breed)
            size = self._size(breed, family, share, puppy)
        else:
            variety = {"value": "Not estimated", "note": "The breed isn't clear enough to name a variety."}
            size = {"value": "Not estimated", "note": "Size category depends on knowing the breed."}

        coat_scores = b.clip_scores(crop, list(COAT_PROMPTS.values()))
        coat, coat_score, coat_ok = best_of(coat_scores, list(COAT_PROMPTS), 0.28)
        colour_scores = b.clip_scores(crop, list(COLOUR_PROMPTS.values()))
        colour, colour_score, colour_ok = best_of(colour_scores, list(COLOUR_PROMPTS), 0.20)

        return {
            "status": "ok", "verdict": verdict, "headline": headline,
            "score": round(score * 100, 1), "breed": breed, "top3": top3, "score_note": SCORE_NOTE,
            "mixed_possible": bool(mixed),
            "mixed_note": ("This dog may be mixed, or a breed outside the 128 this scanner knows. "
                           "A DNA test is the reliable way to find out.") if mixed else None,
            "characteristics": {
                "sex": SEX_RESULT,
                "coat_type": {"value": coat if coat_ok else "Uncertain", "note":
                              "Read from how the coat looks in this photo. That may not match the dog's genetic coat variety. A dog that has been clipped can look very different."},
                "coat_colour": {"value": colour if colour_ok else "Uncertain", "note": "Lighting and shade can change how colour looks in a photo."},
                "size": size, "variety": variety,
            },
            "life_stage": "puppy" if puppy else "adult_or_unknown",
            "warnings": warnings, "model": self.meta.get("metrics"),
        }

    def _groups_differ(self, top3):
        if len(top3) < 2:
            return False
        return self.db.breeds[top3[0]["name"]]["group"] != self.db.breeds[top3[1]["name"]]["group"]

    def _variety(self, label, family, share, puppy, breed):
        if not family:
            return {"value": "Not applicable" if not breed.get("varieties") else "Not estimated from photo", "note": breed.get("varieties")}
        scale = "A photo has nothing to show true height, so treat this as a guess. Measuring at the shoulder is the reliable way."
        if puppy:
            return {"value": "Not estimated for a puppy", "note": "A puppy can look like a smaller variety. " + scale}
        if share < 0.70:
            return {"value": "Size unclear from photo", "note": scale}
        return {"value": f"{label.replace('Poodle (', '').rstrip(')')} {'Poodle' if family == 'Poodle' else ''}".strip() + " (visual estimate)", "note": scale}

    def _size(self, breed, family, share, puppy):
        note = "Toy, Small, Medium, Large and Giant are this site's teaching categories for a typical adult. They are not official AKC categories."
        if family and (share < 0.70 or puppy):
            return {"value": "Depends on variety", "note": note}
        if puppy:
            return {"value": f"{breed['size_category']} (typical adult)", "note": note + " Puppies are smaller than this."}
        return {"value": breed["size_category"], "note": note}
