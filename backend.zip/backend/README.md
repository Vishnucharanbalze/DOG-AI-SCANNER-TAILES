# Backend
Two services. The browser only talks to the Java API; the Java API talks to the AI service.

| Service | Port | Language | Job |
|---|---|---|---|
| `java-api/` | 8080 | Java 17, Spring Boot | Serves the frontend, checks uploads, forwards scans over REST |
| `ai-service/` | 8000 | Python, FastAPI | Dog detection, photo checks, breed classification, coat reading, AKC data |

Run both with `start-windows.bat` in the project root.

**Run them separately**
```
cd backend/ai-service
python -m uvicorn main:app --port 8000

cd backend/java-api
mvn spring-boot:run
```

**Tests:** `python backend/ai-service/tests/test_pipeline.py`
