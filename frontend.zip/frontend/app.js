const $ = (id) => document.getElementById(id);
const MAX_BYTES = 10 * 1024 * 1024;
const TYPES = ['image/jpeg', 'image/png', 'image/webp'];
let chosenFile = null;
let photoDataUrl = null;
let lastResult = null;

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function showError(message) {
  $('error').textContent = message;
  $('error').hidden = false;
}
function clearError() { $('error').hidden = true; }

function setScanning(on) {
  $('sweep').hidden = !on;
  $('scan').disabled = on || !chosenFile;
  $('change').hidden = on || !chosenFile;
  $('status').textContent = on ? 'Scanning your dog. This can take up to a minute.' : '';
}

function acceptFile(file) {
  clearError();
  if (!file) return;
  if (!TYPES.includes(file.type)) { showError('Upload a JPG, PNG or WebP photo. iPhone HEIC photos need converting to JPG first.'); return; }
  if (file.size > MAX_BYTES) { showError('This photo is over 10 MB. Use a smaller one.'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    chosenFile = file;
    photoDataUrl = reader.result;
    $('preview').src = photoDataUrl;
    $('preview').hidden = false;
    $('empty').hidden = true;
    $('scan').disabled = false;
    $('change').hidden = false;
  };
  reader.onerror = () => showError("This file couldn't be read. Try another photo.");
  reader.readAsDataURL(file);
}

function browse() { if (!$('sweep').hidden) return; $('file').value = ''; $('file').click(); }
$('dropzone').addEventListener('click', browse);
$('change').addEventListener('click', browse);
$('dropzone').addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); browse(); } });
$('file').addEventListener('change', (e) => acceptFile(e.target.files[0]));
['dragenter', 'dragover'].forEach((t) => $('dropzone').addEventListener(t, (e) => { e.preventDefault(); $('dropzone').classList.add('dragging'); }));
['dragleave', 'drop'].forEach((t) => $('dropzone').addEventListener(t, (e) => { e.preventDefault(); $('dropzone').classList.remove('dragging'); }));
$('dropzone').addEventListener('drop', (e) => acceptFile(e.dataTransfer.files[0]));

async function scan() {
  if (!chosenFile) return;
  clearError();
  setScanning(true);
  const form = new FormData();
  form.append('file', chosenFile);
  try {
    const response = await fetch('/api/scan', { method: 'POST', body: form });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      showError(data?.detail?.message || 'The scan failed. Try again in a moment.');
    } else if (data.status === 'rejected') {
      showError(data.message);
    } else {
      showResult(data);
    }
  } catch {
    showError("The website can't reach its server. Check that start-windows.bat is still running.");
  }
  setScanning(false);
}
$('scan').addEventListener('click', scan);

function verdictLabel(r) {
  return { confident: 'Best match', likely: 'Likely match', uncertain: 'No breed named' }[r.verdict];
}

function fact(label, value, opts = {}) {
  const v = value === null || value === undefined || value === '' ? null : value;
  const main = v === null ? '<span class="value plain">Not stated in the AKC source</span>' : `<span class="value${opts.plain ? ' plain' : ''}">${esc(v)}</span>`;
  const note = opts.note ? `<small>${esc(opts.note)}</small>` : '';
  const source = opts.source ? `<span class="source${opts.official ? ' official' : ''}">${esc(opts.source)}</span>` : '';
  return `<div class="fact"><dt>${esc(label)}</dt><dd>${main}${note}${source}</dd></div>`;
}

const PAGE = 'AKC breed page data';
const OFFICIAL = 'Summary of the official AKC breed standard';
const EDU = 'General description from AKC breed page';

function standardFacts(b) {
  const o = b.official_standard || {};
  const off = { source: OFFICIAL, official: true, plain: true };
  return [
    fact('Official breed name', b.name, { source: PAGE }),
    fact('AKC breed group', b.group, { source: PAGE }),
    fact('General appearance', b.description, { source: EDU, plain: true }),
    fact('Standard size', o.size, off),
    fact('Height', b.height, { source: PAGE }),
    fact('Weight', b.weight, { source: 'AKC breed weight chart', note: b.weight_note }),
    fact('Coat type', o.coat, off),
    fact('Coat and size varieties', b.varieties || 'None listed in this app', { source: 'AKC', plain: true }),
    fact('Colours and markings', o.color, off),
    fact('Temperament', b.temperament, { source: EDU, plain: true }),
    fact('Grooming', b.grooming, { source: PAGE }),
    fact('Breed characteristics', [b.energy && `Energy: ${b.energy}`, b.shedding && `Shedding: ${b.shedding}`, b.life_expectancy && `Life expectancy: ${b.life_expectancy}`].filter(Boolean).join('. '), { source: PAGE, plain: true }),
  ].join('');
}

function bodyHtml(r) {
  const c = r.characteristics;
  const callouts = [...(r.warnings || []), ...(r.mixed_note ? [r.mixed_note] : [])];
  const top = Math.max(...r.top3.map((t) => t.score), 1);
  const ribbons = r.top3.map((t, i) => `
    <div class="ribbon-row">
      <div class="ribbon-head"><span>${esc(t.name)}</span><span>${t.score}</span></div>
      <div class="ribbon-track"><div class="ribbon r${i}" style="width:${Math.max(4, (t.score / top) * 100)}%"></div></div>
    </div>`).join('');
  const m = r.model;
  const measured = m ? `On ${esc(m.test_images)} held-out test photos, the correct breed was first ${esc(m.top1)}% of the time and in the top 3 ${esc(m.top3)}% of the time. Everyday phone photos may score lower.` : '';
  return `
  <div class="verdict ${r.verdict === 'uncertain' ? 'uncertain' : ''}">
    <p class="verdict-label">${verdictLabel(r)}</p>
    <h2>${esc(r.headline)}</h2>
    ${r.verdict === 'uncertain' ? '<p>The scanner isn\'t sure enough to name a breed. The closest matches are below.</p>' : ''}
  </div>
  ${callouts.length ? `<div class="callout">${callouts.map((w) => `<p>${esc(w)}</p>`).join('')}</div>` : ''}
  <section class="block"><h3>Dog identification</h3>${ribbons}<p class="note">${esc(r.score_note)}</p></section>
  <section class="block"><h3>Dog characteristics</h3><dl class="facts">
    ${fact('Estimated sex', c.sex.value, { note: c.sex.note })}
    ${fact('Coat type', c.coat_type.value, { note: c.coat_type.note })}
    ${fact('Coat colour', c.coat_colour.value, { note: c.coat_colour.note })}
    ${fact('Size category', c.size.value, { note: c.size.note })}
    ${fact('Breed variety', c.variety.value, { note: c.variety.note })}
  </dl></section>
  ${r.breed ? `<section class="block"><h3>AKC breed standards</h3><dl class="facts">${standardFacts(r.breed)}</dl>
    <a class="akc-link" href="${esc(r.breed.akc_url)}" target="_blank" rel="noopener">Official AKC page for this breed</a>
    ${r.breed.official_standard_url ? `<br><a class="akc-link" href="${esc(r.breed.official_standard_url)}" target="_blank" rel="noopener">Official AKC breed standards document (PDF)</a>` : ''}
  </section>` : ''}
  <p class="disclaimer">This is an estimate from one photo. It is not an official AKC identification or conformation assessment, and it doesn't prove a dog's pedigree. ${measured}</p>`;
}

function showResult(r) {
  lastResult = r;
  $('result-img').src = photoDataUrl;
  $('result-body').innerHTML = bodyHtml(r);
  $('home').hidden = true;
  $('result').hidden = false;
  document.body.style.background = 'var(--sky)';
  window.scrollTo(0, 0);
}

$('again').addEventListener('click', () => {
  chosenFile = null; photoDataUrl = null; lastResult = null;
  $('preview').hidden = true; $('preview').removeAttribute('src');
  $('empty').hidden = false;
  $('scan').disabled = true; $('change').hidden = true;
  clearError();
  $('result').hidden = true; $('home').hidden = false;
  document.body.style.background = '';
  window.scrollTo(0, 0);
});

$('report').addEventListener('click', () => {
  if (!lastResult) return;
  const styles = 'body{font:16px/1.5 Arial,sans-serif;color:#141d52;max-width:760px;margin:2rem auto;padding:0 1rem}img{max-width:280px;border-radius:8px}h1,h2,h3{line-height:1.15}.fact{padding:.6rem 0;border-top:1px solid #ccc}dt{font-weight:700}dd{margin:0}small,.source,.note,.disclaimer{display:block;color:#555;font-size:.9rem}.ribbon-head{display:flex;justify-content:space-between;font-weight:700}.ribbon-track{height:12px}.ribbon{height:100%;background:#2340c9}.ribbon-row{margin-bottom:.7rem}.callout{border-left:6px solid #f6bb12;padding:.5rem .8rem}.verdict-label{margin:0}';
  const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>Dog scan report</title><style>${styles}</style><body><h1>AI Dog Scanner report</h1><p>Created ${esc(new Date().toLocaleString())}</p><img src="${photoDataUrl}" alt="Scanned dog">${bodyHtml(lastResult)}</body></html>`;
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
  const name = String(lastResult.headline).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  a.download = `dog-scan-report-${name}.html`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});

async function checkService() {
  try {
    const response = await fetch('/api/health');
    const h = await response.json();
    const state = response.ok ? h.status : h.detail?.code;
    const message = response.ok ? h.detail : h.detail?.message;
    if (state === 'ready') { $('service-notice').hidden = true; return; }
    $('service-notice').textContent = message || 'The AI service is starting.';
    $('service-notice').hidden = false;
    if (state === 'loading' || state === 'starting' || state === 'ai_offline') setTimeout(checkService, 4000);
  } catch { setTimeout(checkService, 4000); }
}
checkService();
