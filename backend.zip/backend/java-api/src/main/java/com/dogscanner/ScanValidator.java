package com.dogscanner;

import java.util.Set;

/** Checks an upload before it is sent to the AI service. Returns an error message, or null when it is fine. */
public final class ScanValidator {
    private static final Set<String> ALLOWED = Set.of("image/jpeg", "image/png", "image/webp");

    private ScanValidator() { }

    public static String problemWith(long size, String contentType) {
        if (size == 0) {
            return "Choose a photo first.";
        }
        if (contentType == null || !ALLOWED.contains(contentType.toLowerCase())) {
            return "Upload a JPG, PNG or WebP photo. iPhone HEIC photos need converting to JPG first.";
        }
        return null;
    }

    public static String errorJson(String code, String message) {
        return "{\"detail\":{\"code\":\"" + code + "\",\"message\":\"" + message.replace("\"", "'") + "\"}}";
    }
}
