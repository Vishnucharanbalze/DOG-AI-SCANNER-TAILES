package com.dogscanner;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

/** Turns an oversized upload into a clear message for the website. */
@RestControllerAdvice
public class UploadErrors {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<String> tooLarge() {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE.value())
                .contentType(MediaType.APPLICATION_JSON)
                .body(ScanValidator.errorJson("too_large", "This photo is over 10 MB. Use a smaller one."));
    }
}
