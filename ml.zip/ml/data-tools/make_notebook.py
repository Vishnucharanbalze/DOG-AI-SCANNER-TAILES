"""Builds notebook/train_dog_scanner.ipynb from the app's own files, so they can't drift apart."""
import base64, gzip, json, runpy
from pathlib import Path
import nbformat as nbf

root = Path(__file__).resolve().parents[2]
maps = runpy.run_path(str(Path(__file__).resolve().parent / "build_breeds.py"))
ai = root / "backend" / "ai-service"
def b64(p): return base64.b64encode(gzip.compress(p.read_bytes())).decode()

md = nbf.v4.new_markdown_cell
code = nbf.v4.new_code_cell
cells = [md("""# AI Dog Scanner: training notebook

**How to use this:** click **Runtime > Change runtime type > T4 GPU > Save**, then **Runtime > Run all**.
Allow Google Drive when asked. It takes about 1.5 to 2.5 hours. Leave the tab open.
At the end, `dog_model.zip` appears in your Google Drive folder `dog_scanner`.

Photo sets: [Tsinghua Dogs](https://cg.cs.tsinghua.edu.cn/ThuDogs/) (cite: Zou et al., 2020) and
[Dog-Breeds-Dataset](https://github.com/AtharvaTaras/Dog-Breeds-Dataset) (CC-BY-4.0)."""),
code("""# Step 1: settings and libraries
import os, sys, subprocess
TEST_MODE = os.environ.get("DOG_TEST_ROOT") is not None
if not TEST_MODE:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "transformers==4.57.1", "timm"], check=True)
import base64, csv, gzip, hashlib, json, random, re, shutil, time, zipfile
from pathlib import Path
import numpy as np, torch, torch.nn.functional as F
from PIL import Image, ImageFile, ImageFilter
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from torchvision import transforms as T
from transformers import AutoImageProcessor, AutoModelForImageClassification
ImageFile.LOAD_TRUNCATED_IMAGES = True

CANDIDATES = ["facebook/convnextv2-tiny-22k-224", "google/efficientnet-b0", "microsoft/resnet-50", "google/mobilenet_v2_1.0_224"]
RUN_COMPARISON = True
FINAL_EPOCHS = 8
COMPARE_EPOCHS = 2
BATCH = 64
TRAIN_CAP = 600
OTHER_CAP = 1500
SEED = 42
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", DEVICE)
if not TEST_MODE and DEVICE != "cuda":
    raise SystemExit("No GPU. Click Runtime > Change runtime type > T4 GPU, then Run all again.")
"""),
code("""# Step 2: connect Google Drive, so nothing is lost if Colab disconnects
if TEST_MODE:
    WORK = Path(os.environ["DOG_TEST_ROOT"]); SAVE = WORK / "drive"
else:
    from google.colab import drive
    drive.mount("/content/drive")
    WORK = Path("/content/work"); SAVE = Path("/content/drive/MyDrive/dog_scanner")
WORK.mkdir(parents=True, exist_ok=True); SAVE.mkdir(parents=True, exist_ok=True)
"""),
code(f"""# Step 3: the 128-breed list and app data
TSINGHUA = {json.dumps(maps["TSINGHUA"])}
OTHER_DOG = {json.dumps(maps["OTHER_DOG"])}
ATHARVA = {json.dumps(maps["ATHARVA"])}
ATHARVA_COMMIT = "7164ba68ce2902e680f92432094a3e028a878dbe"
OTHER = "other_dog"
APP = WORK / "app"; (APP / "data").mkdir(parents=True, exist_ok=True)
(APP / "data/breeds.json").write_bytes(gzip.decompress(base64.b64decode("{b64(ai / 'data' / 'breeds.json')}")))
(APP / "data/labels.json").write_bytes(gzip.decompress(base64.b64decode("{b64(ai / 'data' / 'labels.json')}")))
(APP / "pipeline.py").write_bytes(gzip.decompress(base64.b64decode("{b64(ai / 'pipeline.py')}")))
(APP / "breed_db.py").write_bytes(gzip.decompress(base64.b64decode("{b64(ai / 'breed_db.py')}")))
LABELS = json.loads((APP / "data/labels.json").read_text())
L2I = {{n: i for i, n in enumerate(LABELS)}}
print(len(LABELS), "labels: 130 breed labels (Poodle has 3 varieties, so 128 breeds) + other_dog")
"""),
code("""# Step 4: download the photos (about 2.5 GB). Safe to re-run; it resumes.
if not TEST_MODE:
    z = SAVE / "tsinghua_low.zip"
    for attempt in range(5):
        if zipfile.is_zipfile(z):
            break
        if attempt == 2:
            z.unlink(missing_ok=True)
        if subprocess.run(["wget", "-c", "-q", "--show-progress", "-O", str(z),
                           "https://cloud.tsinghua.edu.cn/f/80013ef29c5f42728fc8/?dl=1"]).returncode == 0 and zipfile.is_zipfile(z):
            break
        print("Download interrupted. Trying again...")
        time.sleep(20)
    else:
        raise SystemExit("The Tsinghua download failed. Run this cell again later.")
    out = WORK / "tsinghua"
    if not out.exists():
        print("Unzipping...")
        with zipfile.ZipFile(z) as f: f.extractall(out)
    if not (WORK / "split").exists():
        subprocess.run(["git", "clone", "-q", "--depth", "1", "https://github.com/dejungle/Tsinghua-Dogs.git", str(WORK / "split")], check=True)
    extra = WORK / "extra"
    if not extra.exists():
        subprocess.run(["git", "clone", "-q", "--filter=blob:none", "--no-checkout", "https://github.com/AtharvaTaras/Dog-Breeds-Dataset.git", str(extra)], check=True)
        subprocess.run(["git", "-C", str(extra), "sparse-checkout", "set", "--no-cone", *[f"/{k}/" for k in ATHARVA]], check=True)
        subprocess.run(["git", "-C", str(extra), "checkout", "-q", ATHARVA_COMMIT], check=True)
print("Photos ready.")
"""),
code("""# Step 5: list every photo and split into train, calibration and test
FOLDER = re.compile(r"^\\d+-n\\d+-(.+)$")
def folder_label(name):
    if name in TSINGHUA: return TSINGHUA[name]
    return OTHER if name in OTHER_DOG else None

index = {}
for p in (WORK / "tsinghua").rglob("*"):
    if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg", ".png"):
        index[(p.parent.name, p.stem)] = p

def read_list(name):
    out = []
    for line in (WORK / "split/split" / name).read_text(encoding="utf-8-sig").splitlines():
        parts = [x for x in line.strip().replace("\\\\", "/").split("/") if FOLDER.match(x)]
        if parts:
            out.append((parts[0], Path(line.strip()).stem))
    return out

rng = random.Random(SEED)
by_class = {}
missing = 0
for key in read_list("train.lst"):
    name = FOLDER.match(key[0]).group(1)
    label = folder_label(name)
    if label is None: continue
    if key not in index: missing += 1; continue
    by_class.setdefault(label, []).append(index[key])
train, calib, test = [], [], []
for label, paths in by_class.items():
    rng.shuffle(paths)
    n = max(4, int(len(paths) * .1))
    calib += [(p, L2I[label]) for p in paths[:n]]
    cap = OTHER_CAP if label == OTHER else TRAIN_CAP
    train += [(p, L2I[label]) for p in paths[n:n + cap]]
for key in read_list("validation.lst"):
    label = folder_label(FOLDER.match(key[0]).group(1))
    if label is None: continue
    if key not in index: missing += 1; continue
    test.append((index[key], L2I[label]))

for folder, label in ATHARVA.items():
    seen, paths = set(), []
    for p in sorted((WORK / "extra" / folder).glob("*")):
        if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"):
            h = hashlib.md5(p.read_bytes()).hexdigest()
            if h not in seen: seen.add(h); paths.append(p)
    rng.shuffle(paths)
    n_test, n_cal = max(1, int(len(paths) * .2)), max(1, int(len(paths) * .1))
    test += [(p, L2I[label]) for p in paths[:n_test]]
    calib += [(p, L2I[label]) for p in paths[n_test:n_test + n_cal]]
    train += [(p, L2I[label]) for p in paths[n_test + n_cal:]]

have = {y for _, y in train}
absent = [LABELS[i] for i in range(len(LABELS)) if i not in have]
if absent: raise SystemExit(f"These labels have no photos: {absent}")
print(f"train {len(train)}, calibration {len(calib)}, test {len(test)}, listed photos not found {missing}")
"""),
code("""# Step 6: training code
class Photos(Dataset):
    def __init__(self, items, tf): self.items, self.tf = items, tf
    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        for _ in range(5):
            path, y = self.items[i]
            try:
                return self.tf(Image.open(path).convert("RGB")), y
            except Exception:
                i = random.randrange(len(self.items))
        raise RuntimeError("Too many unreadable photos")

def proc_size(proc):
    s = proc.size
    return s.get("height") or s.get("shortest_edge") or 224

def transforms_for(name):
    proc = AutoImageProcessor.from_pretrained(name)
    size = proc_size(proc)
    norm = T.Normalize(proc.image_mean, proc.image_std)
    train_tf = T.Compose([T.RandomResizedCrop(size, scale=(.6, 1.)), T.RandomHorizontalFlip(),
                          T.ColorJitter(.2, .2, .2, .03), T.ToTensor(), norm, T.RandomErasing(p=.15)])
    eval_tf = T.Compose([T.Resize(int(size * 1.14)), T.CenterCrop(size), T.ToTensor(), norm])
    return proc, train_tf, eval_tf

def loader(items, tf, sampler=None):
    workers = 0 if TEST_MODE else 2
    return DataLoader(Photos(items, tf), batch_size=BATCH, sampler=sampler, num_workers=workers,
                      pin_memory=DEVICE == "cuda", persistent_workers=workers > 0)

@torch.no_grad()
def collect_logits(model, dl):
    model.eval(); all_logits, ys = [], []
    for x, y in dl:
        with torch.amp.autocast("cuda", enabled=DEVICE == "cuda"):
            logits = model(pixel_values=x.to(DEVICE)).logits
        all_logits.append(logits.float().cpu()); ys.append(y)
    return torch.cat(all_logits), torch.cat(ys)

def accuracy(logits, y, k=1):
    return (logits.topk(k, 1).indices == y[:, None]).any(1).float().mean().item() * 100

def train_model(name, items, cal_items, epochs):
    proc, train_tf, eval_tf = transforms_for(name)
    model = AutoModelForImageClassification.from_pretrained(
        name, num_labels=len(LABELS), ignore_mismatched_sizes=True,
        id2label={i: n for i, n in enumerate(LABELS)}, label2id=L2I).to(DEVICE)
    counts = np.bincount([y for _, y in items], minlength=len(LABELS))
    weights = [1 / np.sqrt(counts[y]) for _, y in items]
    tl = loader(items, train_tf, WeightedRandomSampler(weights, len(items)))
    cl = loader(cal_items, eval_tf)
    head, body = [], []
    for n, p in model.named_parameters():
        (head if "classifier" in n else body).append(p)
    opt = torch.optim.AdamW([{"params": body, "lr": 1.5e-4}, {"params": head, "lr": 1e-3}], weight_decay=.05)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=[1.5e-4, 1e-3], total_steps=max(1, epochs * len(tl)), pct_start=.1)
    scaler = torch.amp.GradScaler("cuda", enabled=DEVICE == "cuda")
    best, best_state = -1, None
    for ep in range(epochs):
        model.train(); t0 = time.time(); total = 0
        for x, y in tl:
            with torch.amp.autocast("cuda", enabled=DEVICE == "cuda"):
                loss = F.cross_entropy(model(pixel_values=x.to(DEVICE)).logits, y.to(DEVICE), label_smoothing=.1)
            opt.zero_grad(); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); sched.step()
            total += loss.item()
        logits, ys = collect_logits(model, cl)
        acc = accuracy(logits, ys)
        print(f"{name} epoch {ep + 1}/{epochs}: loss {total / len(tl):.3f}, calibration top-1 {acc:.1f}%, {time.time() - t0:.0f}s")
        if acc > best:
            best, best_state = acc, {k: v.cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    return model, proc, eval_tf, best
"""),
code("""# Step 7: compare models on a smaller sample, then keep the best one
comparison = {}
final_name = CANDIDATES[0]
if RUN_COMPARISON and len(CANDIDATES) > 1:
    smaller = random.Random(SEED).sample(train, int(len(train) * .35))
    for name in CANDIDATES:
        try:
            model, _, _, acc = train_model(name, smaller, calib, COMPARE_EPOCHS)
            comparison[name] = round(acc, 1)
            del model; torch.cuda.empty_cache() if DEVICE == "cuda" else None
        except Exception as err:
            print("Skipped", name, err)
    if comparison:
        final_name = max(comparison, key=comparison.get)
if not TEST_MODE:
    try:
        from transformers import CLIPModel, CLIPProcessor
        cp = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        cm = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(DEVICE).eval()
        breed_names = LABELS[:-1]
        text = cp(text=[f"a photo of a {n}, a type of dog" for n in breed_names], return_tensors="pt", padding=True).to(DEVICE)
        with torch.inference_mode():
            tf = F.normalize(cm.get_text_features(**text), dim=-1)
        hits, n = 0, 0
        for path, y in [c for c in calib if c[1] != L2I[OTHER]]:
            inp = cp(images=Image.open(path).convert("RGB"), return_tensors="pt").to(DEVICE)
            with torch.inference_mode():
                f = F.normalize(cm.get_image_features(**inp), dim=-1)
            hits += int((f @ tf.T).argmax() == y); n += 1
        comparison["openai/clip-vit-base-patch32 (no training)"] = round(hits / n * 100, 1)
        del cm; torch.cuda.empty_cache()
    except Exception as err:
        print("CLIP comparison skipped:", err)
print("Comparison (calibration top-1 %):", json.dumps(comparison, indent=1))
print("Training final model:", final_name)
"""),
code("""# Step 8: train the final model
model, proc, eval_tf, best = train_model(final_name, train, calib, FINAL_EPOCHS)
OUT = WORK / "dog_model"; shutil.rmtree(OUT, ignore_errors=True); (OUT / "classifier").mkdir(parents=True)
model.save_pretrained(OUT / "classifier"); proc.save_pretrained(OUT / "classifier")
print("Saved. Best calibration top-1:", round(best, 1))
"""),
code("""# Step 9: calibrate the scores and choose when the app may name a breed
cal_logits, cal_y = collect_logits(model, loader(calib, eval_tf))
log_t = torch.zeros(1, requires_grad=True)
opt = torch.optim.LBFGS([log_t], lr=.1, max_iter=100)
def closure():
    opt.zero_grad(); loss = F.cross_entropy(cal_logits / log_t.exp(), cal_y); loss.backward(); return loss
opt.step(closure)
temperature = float(log_t.exp())
conf, pred = (cal_logits / temperature).softmax(1).max(1)
order = conf.argsort(descending=True)
running = (pred[order] == cal_y[order]).float().cumsum(0) / torch.arange(1, len(order) + 1)
def threshold(target, default):
    ok = (running >= target).nonzero()
    return float(conf[order][ok[-1]]) if len(ok) else default
likely = min(.70, max(.30, threshold(.70, .50)))
confident = min(.95, max(likely + .05, threshold(.90, .80)))
print(f"temperature {temperature:.3f}, likely at {likely:.2f}, confident at {confident:.2f}")
"""),
code("""# Step 10: measure accuracy on photos the model never trained on
test_logits, test_y = collect_logits(model, loader(test, eval_tf))
keep = test_y != L2I[OTHER]
logits, ys = test_logits[keep], test_y[keep]
top1, top3 = accuracy(logits, ys), accuracy(logits, ys, 3)
per = []
pred1 = logits.argmax(1)
for i, n in enumerate(LABELS[:-1]):
    m = ys == i
    if m.sum(): per.append((n, int(m.sum()), round(float((pred1[m] == i).float().mean()) * 100, 1)))
with open(OUT / "per_breed_accuracy.csv", "w", newline="") as f:
    csv.writer(f).writerows([("breed", "test_photos", "top1_percent"), *sorted(per, key=lambda r: r[2])])
SPEC = ["German Shepherd Dog", "Labrador Retriever", "Golden Retriever", "Cane Corso", "Rottweiler", "Pomeranian", "Siberian Husky", "Beagle",
        "Poodle (Standard)", "Poodle (Miniature)", "Poodle (Toy)", "Miniature Schnauzer"]
print(f"Test photos {int(keep.sum())}: top-1 {top1:.1f}%, top-3 {top3:.1f}%")
for r in per:
    if r[0] in SPEC: print(r)
print("Weakest 10:", sorted(per, key=lambda r: r[2])[:10])
metrics = {"model": final_name, "test_images": int(keep.sum()), "top1": round(top1, 1), "top3": round(top3, 1),
           "trained_on": time.strftime("%Y-%m-%d"), "comparison_calibration_top1": comparison,
           "spec_breeds": {r[0]: {"photos": r[1], "top1": r[2]} for r in per if r[0] in SPEC}}
meta = {"labels": LABELS, "temperature": temperature, "threshold_likely": likely, "threshold_confident": confident,
        "blur_threshold": 20.0, "metrics": metrics}
(OUT / "model_meta.json").write_text(json.dumps(meta, indent=1))
"""),
code("""# Step 11: test the whole scanner on cats, people, blurry photos and two-dog photos
def guard_tests():
    sys.path.insert(0, str(APP))
    import importlib, io, pipeline; importlib.reload(pipeline)
    from torchvision import datasets as tvd
    scanner = pipeline.DogScanner(APP / "data", OUT)
    def jpeg(img):
        b = io.BytesIO(); img.convert("RGB").save(b, "JPEG", quality=92); return b.getvalue()
    def rate(images, wanted):
        codes = [scanner.scan(jpeg(i)).get("code", "accepted") for i in images]
        return {"photos": len(codes), "handled_as_expected_percent": round(100 * sum(c in wanted for c in codes) / max(1, len(codes)), 1)}
    results = {}
    sample = random.Random(SEED).sample([t for t in test if t[1] != L2I[OTHER]], 200)
    dogs = [Image.open(p).convert("RGB") for p, _ in sample]
    sharp = [pipeline.sharpness(d) for d in dogs]
    blurred = [d.filter(ImageFilter.GaussianBlur(max(d.size) / 60)) for d in dogs]
    meta["blur_threshold"] = float(np.percentile(sharp, 3))
    scanner.meta["blur_threshold"] = meta["blur_threshold"]
    results["blurry_rejected"] = rate(blurred, {"too_blurry", "dog_unclear", "not_a_dog"})
    results["dog_photos_accepted"] = rate(dogs, {"accepted"})
    pairs = []
    for a, b in zip(dogs[:60], dogs[60:120]):
        canvas = Image.new("RGB", (800, 400), "white")
        canvas.paste(a.resize((400, 400)), (0, 0)); canvas.paste(b.resize((400, 400)), (400, 0)); pairs.append(canvas)
    results["two_dogs_flagged"] = rate(pairs, {"multiple_dogs"})
    try:
        pets = tvd.OxfordIIITPet(WORK / "pets", download=True, target_types="binary-category")
        cats = [pets[i][0] for i in range(len(pets)) if pets[i][1] == 0][:200]
        results["cats_rejected"] = rate(cats, {"not_a_dog"})
    except Exception as err:
        results["cats_rejected"] = f"skipped: {err}"
    try:
        lfw = tvd.LFWPeople(WORK / "lfw", download=True)
        people = [lfw[i][0] for i in random.Random(SEED).sample(range(len(lfw)), 200)]
        results["people_rejected"] = rate(people, {"not_a_dog"})
    except Exception as err:
        results["people_rejected"] = f"skipped: {err}"
    return results

if TEST_MODE:
    print("Skipping guard tests in test mode")
else:
    metrics["guards"] = guard_tests()
    print(json.dumps(metrics["guards"], indent=1))
(OUT / "model_meta.json").write_text(json.dumps(meta, indent=1))
"""),
code("""# Step 12: save dog_model.zip to Google Drive
target = SAVE / "dog_model.zip"
with zipfile.ZipFile(target, "w", zipfile.ZIP_STORED) as z:
    for p in OUT.rglob("*"):
        if p.is_file():
            z.write(p, p.relative_to(OUT))
print("Done.", target, round(target.stat().st_size / 1e6), "MB")
print(json.dumps({k: metrics[k] for k in ("model", "test_images", "top1", "top3")}, indent=1))
"""),
]
nb = nbf.v4.new_notebook(cells=cells, metadata={"accelerator": "GPU", "kernelspec": {"name": "python3", "display_name": "Python 3"}})
nb.metadata["colab"] = {"gpuType": "T4"}
out = root / "ml" / "notebook" / "train_dog_scanner.ipynb"
nbf.write(nb, str(out))
print("wrote", out, out.stat().st_size)
