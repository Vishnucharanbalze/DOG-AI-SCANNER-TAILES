package com.dogscanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogScannerApplication {
    public static void main(String[] args) {
        SpringApplication.run(DogScannerApplication.class, args);
    }
}
