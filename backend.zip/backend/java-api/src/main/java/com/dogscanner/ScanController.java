package com.dogscanner;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class ScanController {

    private final AiServiceClient ai;

    public ScanController(@Value("${ai.service.url}") String aiServiceUrl) {
        this.ai = new AiServiceClient(aiServiceUrl);
    }

    @GetMapping("/api/health")
    public ResponseEntity<String> health() {
        return forward(ai.health());
    }

    @PostMapping("/api/scan")
    public ResponseEntity<String> scan(@RequestParam("file") MultipartFile file) throws IOException {
        String problem = ScanValidator.problemWith(file.getSize(), file.getContentType());
        if (problem != null) {
            return json(HttpStatus.BAD_REQUEST.value(), ScanValidator.errorJson("bad_upload", problem));
        }
        return forward(ai.scan(file.getBytes(), file.getContentType()));
    }

    private ResponseEntity<String> forward(AiServiceClient.Reply reply) {
        return json(reply.status(), reply.body());
    }

    private ResponseEntity<String> json(int status, String body) {
        return ResponseEntity.status(status).contentType(MediaType.APPLICATION_JSON).body(body);
    }
}
