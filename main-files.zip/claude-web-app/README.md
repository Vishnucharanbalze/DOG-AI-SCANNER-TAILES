# AI Dog Scanner (claude.ai version)
This is the page published as an artifact on claude.ai. It uses Claude's built-in vision,
so scanning only works when it is opened inside claude.ai. Opened anywhere else, the page
loads but Scan Dog shows "Photo analysis needs this page to be open in claude.ai".
