"""AI service. The Java website calls this. Start it with start-windows.bat."""
import threading
import traceback
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile

from pipeline import DogScanner

BASE = Path(__file__).resolve().parent
MODEL_DIR = BASE / "model"
DATA_DIR = BASE / "data"
MAX_BYTES = 10 * 1024 * 1024

app = FastAPI(title="AI Dog Scanner service")
state = {"scanner": None, "status": "starting", "detail": None}
lock = threading.Lock()


def model_installed():
    return (MODEL_DIR / "classifier" / "config.json").exists() and (MODEL_DIR / "model_meta.json").exists()


def load_models():
    if not model_installed():
        state.update(status="model_not_installed",
                     detail="The trained breed model isn't installed yet. Follow Part 2 of START-HERE.html.")
        return
    state.update(status="loading", detail="Loading AI models. The first run downloads about 600 MB.")
    try:
        state["scanner"] = DogScanner(DATA_DIR, MODEL_DIR)
        state.update(status="ready", detail=None)
    except Exception as err:
        traceback.print_exc()
        state.update(status="load_failed", detail=f"The AI models could not load: {err}")


@app.on_event("startup")
def startup():
    threading.Thread(target=load_models, daemon=True).start()


@app.get("/health")
def health():
    scanner = state["scanner"]
    return {"status": state["status"], "detail": state["detail"],
            "metrics": scanner.meta.get("metrics") if scanner else None}


@app.post("/scan")
def scan(file: UploadFile = File(...)):
    if state["status"] != "ready":
        raise HTTPException(503, detail={"code": state["status"], "message": state["detail"] or "The AI service is starting."})
    data = file.file.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise HTTPException(413, detail={"code": "too_large", "message": "This photo is over 10 MB. Use a smaller one."})
    if not data:
        raise HTTPException(400, detail={"code": "empty", "message": "The uploaded file is empty."})
    try:
        with lock:
            return state["scanner"].scan(data)
    except Exception:
        traceback.print_exc()
        raise HTTPException(500, detail={"code": "scan_failed", "message": "The scan failed on this photo. Try another one."})
