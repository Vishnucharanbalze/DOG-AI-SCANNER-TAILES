"""Builds ai_service/data/breeds.json and ai_service/data/labels.json.

You do not need to run this. It is kept so the data can be audited and rebuilt.

Sources
  1. AKC Breed Weight Chart (WEIGHT_CHART below, copied from
     https://www.akc.org/expert-advice/nutrition/breed-weight-chart/ on 2026-11-09).
  2. tmfilho/akcdata (open snapshot of AKC breed pages): group, height, temperament,
     grooming, description. https://github.com/tmfilho/akcdata
Usage: python build_breeds.py path/to/akc-data-latest.csv
"""
import csv, json, re, sys
from pathlib import Path

# Dataset folder name -> AKC name. Tsinghua Dogs classes (cg.cs.tsinghua.edu.cn/ThuDogs).
TSINGHUA = {
 "affenpinscher":"Affenpinscher","Afghan_hound":"Afghan Hound","Airedale":"Airedale Terrier",
 "American_Staffordshire_terrier":"American Staffordshire Terrier","Australian_Shepherd":"Australian Shepherd",
 "Australian_terrier":"Australian Terrier","basenji":"Basenji","basset":"Basset Hound","beagle":"Beagle",
 "Bedlington_terrier":"Bedlington Terrier","Bernese_mountain_dog":"Bernese Mountain Dog","Bichon_Frise":"Bichon Frise",
 "black_and_tan_coonhound":"Black and Tan Coonhound","Blenheim_spaniel":"Cavalier King Charles Spaniel",
 "bloodhound":"Bloodhound","bluetick":"Bluetick Coonhound","Border_collie":"Border Collie","Border_terrier":"Border Terrier",
 "borzoi":"Borzoi","Boston_bull":"Boston Terrier","Bouvier_des_Flandres":"Bouvier des Flandres","boxer":"Boxer",
 "Brabancon_griffo":"Brussels Griffon","briard":"Briard","Brittany_spaniel":"Brittany","bull_mastiff":"Bullmastiff",
 "cairn":"Cairn Terrier","Cane_Carso":"Cane Corso","Cardigan":"Cardigan Welsh Corgi",
 "Chesapeake_Bay_retriever":"Chesapeake Bay Retriever","Chihuahua":"Chihuahua","Chinese_Crested_Dog":"Chinese Crested",
 "chow":"Chow Chow","clumber":"Clumber Spaniel","cocker_spaniel":"Cocker Spaniel","collie":"Collie",
 "curly_coated_retriever":"Curly-Coated Retriever","Dandie_Dinmont":"Dandie Dinmont Terrier","Doberman":"Doberman Pinscher",
 "English_foxhound":"English Foxhound","English_setter":"English Setter","English_springer":"English Springer Spaniel",
 "EntleBucher":"Entlebucher Mountain Dog","flat_coated_retriever":"Flat-Coated Retriever","French_bulldog":"French Bulldog",
 "German_shepherd":"German Shepherd Dog","German_short_haired_pointer":"German Shorthaired Pointer",
 "giant_schnauzer":"Giant Schnauzer","golden_retriever":"Golden Retriever","Gordon_setter":"Gordon Setter",
 "Great_Dane":"Great Dane","Great_Pyrenees":"Great Pyrenees","Greater_Swiss_Mountain_dog":"Greater Swiss Mountain Dog",
 "groenendael":"Belgian Sheepdog","Ibizan_hound":"Ibizan Hound","Irish_setter":"Irish Setter","Irish_terrier":"Irish Terrier",
 "Irish_water_spaniel":"Irish Water Spaniel","Irish_wolfhound":"Irish Wolfhound","Italian_greyhound":"Italian Greyhound",
 "Japanese_spaniel":"Japanese Chin","keeshond":"Keeshond","Kerry_blue_terrier":"Kerry Blue Terrier","komondor":"Komondor",
 "kuvasz":"Kuvasz","Labrador_retriever":"Labrador Retriever","Lakeland_terrier":"Lakeland Terrier","Leonberg":"Leonberger",
 "Lhasa":"Lhasa Apso","malamute":"Alaskan Malamute","malinois":"Belgian Malinois","Maltese_dog":"Maltese",
 "Mexican_hairless":"Xoloitzcuintli","miniature_pinscher":"Miniature Pinscher","miniature_poodle":"Poodle (Miniature)",
 "miniature_schnauzer":"Miniature Schnauzer","Newfoundland":"Newfoundland","Norfolk_terrier":"Norfolk Terrier",
 "Norwegian_elkhound":"Norwegian Elkhound","Norwich_terrier":"Norwich Terrier","Old_English_sheepdog":"Old English Sheepdog",
 "otterhound":"Otterhound","papillon":"Papillon","Pekinese":"Pekingese","Pembroke":"Pembroke Welsh Corgi",
 "Pomeranian":"Pomeranian","pug":"Pug","redbone":"Redbone Coonhound","Rhodesian_ridgeback":"Rhodesian Ridgeback",
 "Rottweiler":"Rottweiler","Saint_Bernard":"Saint Bernard","Saluki":"Saluki","Samoyed":"Samoyed","schipperke":"Schipperke",
 "Scotch_terrier":"Scottish Terrier","Scottish_deerhound":"Scottish Deerhound","Sealyham_terrier":"Sealyham Terrier",
 "Shetland_sheepdog":"Shetland Sheepdog","Shiba_Dog":"Shiba Inu","Shih_Tzu":"Shih Tzu","Siberian_husky":"Siberian Husky",
 "silky_terrier":"Silky Terrier","soft_coated_wheaten_terrier":"Soft Coated Wheaten Terrier",
 "Staffordshire_bullterrier":"Staffordshire Bull Terrier","standard_poodle":"Poodle (Standard)",
 "standard_schnauzer":"Standard Schnauzer","Sussex_spaniel":"Sussex Spaniel","Tibetan_mastiff":"Tibetan Mastiff",
 "Tibetan_terrier":"Tibetan Terrier","toy_poodle":"Poodle (Toy)","vizsla":"Vizsla","Walker_hound":"Treeing Walker Coonhound",
 "Weimaraner":"Weimaraner","Welsh_springer_spaniel":"Welsh Springer Spaniel",
 "West_Highland_white_terrier":"West Highland White Terrier","whippet":"Whippet","wire_haired_fox_terrier":"Wire Fox Terrier",
 "Yorkshire_terrier":"Yorkshire Terrier",
}
# Dog types in the photo set that are not in the 128-breed list. They train an
# "other dog" class, so unlisted and mixed-looking dogs do not get forced into a breed.
OTHER_DOG = ["African_hunting_dog","Appenzeller","Black_sable","chinese_rural_dog","dhole","dingo",
             "Eskimo_dog","Fila Braziliero","Japanese_Spitzes","kelpie","toy_terrier"]
# Left out: "teddy" is a haircut, not a breed.
EXCLUDED = ["teddy"]
# Folder names in github.com/AtharvaTaras/Dog-Breeds-Dataset (CC-BY-4.0).
ATHARVA = {
 "dachshund dog":"Dachshund","bulldog":"Bulldog","havanese dog":"Havanese","australian cattle dog":"Australian Cattle Dog",
 "mastiff dog":"Mastiff","dalmatian dog":"Dalmatian","american akita dog":"Akita","bull terrier dog":"Bull Terrier",
 "shar pei dog":"Chinese Shar-Pei","greyhound dog":"Greyhound","english pointer dog":"Pointer",
 "portuguese water dog":"Portuguese Water Dog",
}

WEIGHT_CHART = """Affenpinscher|7-10|7-10
Afghan Hound|50-60|50-60
Airedale Terrier|50-70|50-70
Akita|70-130|70-130
Alaskan Malamute|75-85|75-85
American Staffordshire Terrier|40-70|40-70
Australian Cattle Dog|35-50|35-50
Australian Shepherd|40-65|40-65
Australian Terrier|15-20|15-20
Basenji|22-24|22-24
Basset Hound|40-65|40-65
Beagle|15-13|15-13
Bedlington Terrier|17-23|17-23
Belgian Malinois|40-80|40-80
Belgian Sheepdog|45-75|45-75
Bernese Mountain Dog|70-115|70-115
Bichon Frise|12-18|12-18
Black and Tan Coonhound|65-110|65-110
Bloodhound|80-110|80-110
Bluetick Coonhound|45-80|45-80
Border Collie|30-55|30-55
Border Terrier|11.5-15.5|11.5-15.5
Borzoi|60-105|60-105
Boston Terrier|12-25|12-25
Bouvier des Flandres|70-110|70-110
Boxer|15-80|15-80
Briard|55-100|55-100
Brittany|30-40|30-40
Brussels Griffon|8-10|8-10
Bull Terrier|50-70|50-70
Bulldog|40-50|40-50
Bullmastiff|100-130|100-130
Cairn Terrier|13-14|13-14
Cardigan Welsh Corgi|25-38|25-38
Cavalier King Charles Spaniel|13-18|13-18
Chesapeake Bay Retriever|55-80|55-80
Chihuahua|6-6|6-6
Chinese Crested|8-12|8-12
Chinese Shar-Pei|45-60|45-60
Chow Chow|45-70|45-70
Clumber Spaniel|55-85|55-85
Cocker Spaniel|20-30|20-30
Collie|50-75|50-75
Curly-Coated Retriever|60-95|60-95
Dachshund|11-32|11-32
Dalmatian|45-70|45-70
Dandie Dinmont Terrier|18-24|18-24
Doberman Pinscher|60-100|60-100
English Foxhound|60-75|60-75
English Setter|45-80|45-80
English Springer Spaniel|40-50|40-50
Entlebucher Mountain Dog|40-65|40-65
Flat-Coated Retriever|60-70|60-70
French Bulldog|28-28|28-28
German Shepherd Dog|50-90|50-90
German Shorthaired Pointer|45-70|45-70
Giant Schnauzer|75-95|55-80
Golden Retriever|55-75|55-75
Gordon Setter|45-80|45-80
Great Dane|110-175|110-175
Great Pyrenees|85-100|85-100
Greater Swiss Mountain Dog|85-140|85-140
Greyhound|60-70|60-70
Havanese|7-13|7-13
Ibizan Hound|45-50|45-50
Irish Setter|60-70|60-70
Irish Terrier|25-27|25-27
Irish Water Spaniel|45-68|45-68
Irish Wolfhound|105-120|105-120
Italian Greyhound|7-14|7-14
Japanese Chin|7-11|7-11
Keeshond|35-45|35-45
Kerry Blue Terrier|33-40|33-40
Komondor|80-100|80-100
Kuvasz|70-115|70-115
Labrador Retriever|55-80|55-80
Lakeland Terrier|17-17|17-17
Leonberger|90-170|90-170
Lhasa Apso|12-18|12-18
Maltese|7-7|7-7
Mastiff|120-230|120-230
Miniature Pinscher|8-10|8-10
Miniature Schnauzer|11-20|11-20
Newfoundland|100-150|100-150
Norfolk Terrier|11-12|11-12
Norwegian Elkhound|48-55|48-55
Norwich Terrier|12-12|12-12
Old English Sheepdog|60-100|60-100
Otterhound|80-115|80-115
Papillon|5-10|5-10
Pekingese|14-14|14-14
Pembroke Welsh Corgi|28-30|28-30
Pointer|45-75|45-75
Pomeranian|3-7|3-7
Poodle (Miniature)|10-15|10-15
Poodle (Standard)|40-70|40-70
Poodle (Toy)|4-6|4-6
Portuguese Water Dog|35-60|35-60
Pug|14-18|14-18
Redbone Coonhound|45-70|45-70
Rhodesian Ridgeback|70-85|70-85
Rottweiler|80-135|80-135
Saint Bernard|120-180|120-180
Saluki|40-65|40-65
Samoyed|35-65|35-65
Schipperke|10-16|10-16
Scottish Deerhound|85-110|75-95
Scottish Terrier|18-22|18-22
Sealyham Terrier|23-24|23-24
Shetland Sheepdog|15-25|15-25
Shiba Inu|17-23|17-23
Shih Tzu|9-16|9-16
Siberian Husky|35-60|35-60
Silky Terrier|10-10|10-10
Soft Coated Wheaten Terrier|30-40|30-40
Staffordshire Bull Terrier|24-38|24-38
Standard Schnauzer|30-50|30-50
Sussex Spaniel|35-45|35-45
Tibetan Mastiff|70-150|70-150
Tibetan Terrier|18-30|18-30
Treeing Walker Coonhound|50-70|50-70
Vizsla|44-60|44-60
Weimaraner|55-90|55-90
Welsh Springer Spaniel|35-55|35-55
West Highland White Terrier|15-20|15-20
Whippet|25-40|25-40
Wire Fox Terrier|15-18|15-18
Xoloitzcuintli|10-55|10-55
Yorkshire Terrier|7-7|7-7"""
CHART = {}
for line in WEIGHT_CHART.splitlines():
    n, m, f = line.split("|"); CHART[n] = (m, f)

# The AKC chart has a garbled or misleading figure for these, so no weight is shown.
UNRELIABLE_WEIGHT = {
    "Beagle": "AKC's chart shows a garbled value for this breed. See the AKC page.",
    "Boxer": "AKC's chart shows 15-80 lb, which looks like a data error. See the AKC page.",
}
PUBLISHED_NO_NUMBER = {"Cane Corso": "Proportionate to height (AKC publishes no numeric weight)"}
HEIGHT_TEXT = {
    "Poodle (Toy)": "10 in or under", "Poodle (Miniature)": "Over 10 in, up to 15 in",
    "Poodle (Standard)": "Over 15 in",
}
VARIETIES = {
    "Poodle (Toy)": "Toy, Miniature and Standard are the three AKC Poodle varieties, separated by height at the shoulder.",
    "Poodle (Miniature)": "Toy, Miniature and Standard are the three AKC Poodle varieties, separated by height at the shoulder.",
    "Poodle (Standard)": "Toy, Miniature and Standard are the three AKC Poodle varieties, separated by height at the shoulder.",
    "Dachshund": "AKC sizes: Standard and Miniature. AKC coats: Smooth, Wirehaired and Longhaired.",
    "Beagle": "AKC varieties: 13 inches and under, and over 13 up to 15 inches.",
    "Chihuahua": "AKC coat varieties: Smooth Coat and Long Coat.",
    "Collie": "AKC coat varieties: Rough and Smooth.",
    "Bull Terrier": "AKC varieties: White and Colored.",
    "Chinese Crested": "AKC coat types: Hairless and Powderpuff.",
    "Xoloitzcuintli": "AKC sizes: Toy, Miniature and Standard. AKC coats: Hairless and Coated.",
    "Giant Schnauzer": "Giant, Standard and Miniature Schnauzers are three separate AKC breeds.",
    "Standard Schnauzer": "Giant, Standard and Miniature Schnauzers are three separate AKC breeds.",
    "Miniature Schnauzer": "Giant, Standard and Miniature Schnauzers are three separate AKC breeds.",
}
SLUG_OVERRIDE = {"Poodle (Toy)": "poodle-toy", "Poodle (Miniature)": "poodle-miniature", "Poodle (Standard)": "poodle-standard"}

# The AKC Poodle standard is published once, in the Non-Sporting Group document.
STANDARD_GROUP = {"Poodle (Toy)": "Non-Sporting Group"}

def lb(kg): return round(float(kg) * 2.20462, 1)
def fmt(x): return ("%g" % x)
def range_text(a, b): return f"{fmt(a)} in" if a == b else f"{fmt(a)} to {fmt(b)} in"

def weight_info(name, row):
    """Returns (weight_text, midpoint_lb or None)."""
    if name in PUBLISHED_NO_NUMBER: return PUBLISHED_NO_NUMBER[name], None
    if name in UNRELIABLE_WEIGHT: return None, None
    def one(s):
        a, b = [float(v) for v in s.split("-")]
        return (f"about {fmt(a)} lb (AKC lists one figure)" if a == b else f"{fmt(a)} to {fmt(b)} lb"), (a * 0.85 if a == b else (a + b) / 2)
    male, female = CHART[name]
    tm, mm = one(male)
    if male == female: return tm, mm
    tf, mf = one(female)
    return f"Males {tm}, females {tf}", (mm + mf) / 2

def category(mid_lb, height_mid):
    """Educational size bands. These are NOT AKC categories."""
    if mid_lb is not None:
        return "Toy" if mid_lb < 10 else "Small" if mid_lb < 25 else "Medium" if mid_lb < 55 else "Large" if mid_lb <= 105 else "Giant"
    return "Toy" if height_mid < 11 else "Small" if height_mid < 16 else "Medium" if height_mid < 22 else "Large" if height_mid < 28 else "Giant"

GROUP_PDF = {
    "Terrier Group": "https://images.akc.org/pdf/judges/groups/Terrier_Group.pdf",
    "Working Group": "https://images.akc.org/pdf/judges/groups/Working_Group.pdf",
    "Sporting Group": "https://images.akc.org/pdf/judges/groups/Sporting_Group.pdf",
    "Herding Group": "https://images.akc.org/pdf/judges/Herding_Group_7-16.pdf",
    "Hound Group": "https://images.akc.org/pdf/judges/groups/Hound_Group.pdf",
    "Toy Group": "https://images.akc.org/pdf/judges/groups/Toy_Group.pdf",
    "Non-Sporting Group": "https://images.akc.org/pdf/judges/groups/Non-Sporting_Group.pdf",
}

def load_standards():
    out = {}
    for line in (Path(__file__).parent / "akc_standards_summary.txt").read_text(encoding="utf8").splitlines():
        if line and not line.startswith("#"):
            name, size, coat, color = line.split("|")
            out[name] = {k: (None if v == "?" else v) for k, v in dict(size=size, coat=coat, color=color).items()}
    return out

def main(csv_path):
    rows = {r[""]: r for r in csv.DictReader(open(csv_path, encoding="utf8"))}
    standards = load_standards()
    names = sorted(set(TSINGHUA.values()) | set(ATHARVA.values()))
    assert len(names) == 130, len(names)
    breeds = {}
    for n in names:
        r = rows[n]; assert "Group" in r["group"], n
        a, b = round(float(r["min_height"]) / 2.54, 1), round(float(r["max_height"]) / 2.54, 1)
        wt, mid = weight_info(n, r)
        slug = SLUG_OVERRIDE.get(n, re.sub(r"[^a-z0-9]+", "-", n.lower()).strip("-"))
        breeds[n] = {
            "name": n, "group": r["group"],
            "height": HEIGHT_TEXT.get(n, range_text(a, b)),
            "weight": wt, "weight_note": UNRELIABLE_WEIGHT.get(n),
            "description": re.sub(r"\s+", " ", r["description"]).strip(),
            "temperament": r["temperament"], "grooming": r["grooming_frequency_category"] or None,
            "shedding": r["shedding_category"] or None, "energy": r["energy_level_category"] or None,
            "life_expectancy": f"{fmt(float(r['min_expectancy']))} to {fmt(float(r['max_expectancy']))} years" if r["min_expectancy"] else None,
            "size_category": category(mid, (a + b) / 2), "varieties": VARIETIES.get(n),
            "akc_url": f"https://www.akc.org/dog-breeds/{slug}/",
            "official_standard": standards[n.split(" (")[0]],
            "official_standard_url": GROUP_PDF[STANDARD_GROUP.get(n, r["group"])],
        }
    out = Path(__file__).resolve().parents[2] / "backend" / "ai-service" / "data"
    out.mkdir(parents=True, exist_ok=True)
    (out / "breeds.json").write_text(json.dumps(breeds, indent=1, ensure_ascii=False), encoding="utf8")
    labels = names + ["other_dog"]
    (out / "labels.json").write_text(json.dumps(labels, indent=0), encoding="utf8")
    print(len(breeds), "records; AKC breeds counting Poodle once:", len({n.split(" (")[0] for n in names}))

if __name__ == "__main__":
    main(sys.argv[1])
