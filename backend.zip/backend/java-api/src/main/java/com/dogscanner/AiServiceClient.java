package com.dogscanner;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;

/** Talks to the Python AI service over REST. Uses only the standard Java library. */
public class AiServiceClient {

    public record Reply(int status, String body) { }

    private static final String OFFLINE = "{\"detail\":{\"code\":\"ai_offline\",\"message\":"
            + "\"The AI service isn't running. Close this site's black windows and run start-windows.bat again.\"}}";

    private final String baseUrl;
    private final HttpClient http = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    public AiServiceClient(String baseUrl) {
        this.baseUrl = baseUrl.replaceAll("/+$", "");
    }

    public Reply health() {
        HttpRequest request = HttpRequest.newBuilder(URI.create(baseUrl + "/health"))
                .timeout(Duration.ofSeconds(5)).GET().build();
        return send(request);
    }

    public Reply scan(byte[] image, String contentType) {
        String boundary = "----dogscanner" + UUID.randomUUID().toString().replace("-", "");
        HttpRequest request = HttpRequest.newBuilder(URI.create(baseUrl + "/scan"))
                .timeout(Duration.ofSeconds(180))
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(multipart(image, contentType, boundary)))
                .build();
        return send(request);
    }

    private Reply send(HttpRequest request) {
        try {
            HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            return new Reply(response.statusCode(), response.body());
        } catch (IOException e) {
            return new Reply(503, OFFLINE);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new Reply(503, OFFLINE);
        }
    }

    private static byte[] multipart(byte[] image, String contentType, String boundary) {
        String head = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"file\"; filename=\"photo\"\r\n"
                + "Content-Type: " + contentType + "\r\n\r\n";
        String tail = "\r\n--" + boundary + "--\r\n";
        ByteArrayOutputStream out = new ByteArrayOutputStream(image.length + 256);
        out.writeBytes(head.getBytes(StandardCharsets.UTF_8));
        out.writeBytes(image);
        out.writeBytes(tail.getBytes(StandardCharsets.UTF_8));
        return out.toByteArray();
    }
}
