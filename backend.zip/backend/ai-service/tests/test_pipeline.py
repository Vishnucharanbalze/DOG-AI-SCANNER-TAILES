"""Checks the scanner's decisions using stand-in models. Run: python tests/test_pipeline.py
These tests check the logic only. Real accuracy is measured in the Colab notebook."""
import io, json, sys, tempfile
from pathlib import Path

import numpy as np
from PIL import Image

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
import pipeline  # noqa: E402

LABELS = json.loads((BASE / "data/labels.json").read_text())


def jpeg(size=(600, 500), flat=False, value=None):
    rng = np.random.default_rng(1)
    if flat:
        arr = np.full((size[1], size[0], 3), value if value is not None else 128, np.uint8)
    else:
        arr = rng.integers(60, 200, (size[1], size[0], 3), dtype=np.uint8)
    out = io.BytesIO(); Image.fromarray(arr).save(out, "JPEG", quality=95)
    return out.getvalue()


class Fake:
    def __init__(self, dets=None, probs=None, puppy=False):
        self.dets = [("dog", .95, (20, 20, 560, 460))] if dets is None else dets
        self.probs, self.puppy = probs, puppy

    def detect(self, img): return self.dets

    def classify_logits(self, img):
        p = np.full(len(LABELS), 1e-6)
        for k, v in self.probs.items(): p[LABELS.index(k)] = v
        return np.log(p / p.sum())

    def clip_scores(self, img, prompts):
        if len(prompts) == 2: return np.array([.9, .1] if self.puppy else [.1, .9])
        p = np.full(len(prompts), .1 / max(1, len(prompts) - 1)); p[0] = .9
        return p


def run(fake, data=None):
    with tempfile.TemporaryDirectory() as d:
        return pipeline.DogScanner(BASE / "data", Path(d), backends=fake).scan(data or jpeg())


GSD = {"German Shepherd Dog": .9, "Rottweiler": .06, "Beagle": .04}
failures = 0
def check(name, cond, got=None):
    global failures
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"  got {got}"))
    failures += 0 if cond else 1


r = run(Fake(probs=GSD))
check("confident breed named", r["status"] == "ok" and r["verdict"] == "confident" and r["headline"] == "German Shepherd Dog", r)
check("top 3 in order", [t["name"] for t in r["top3"]] == ["German Shepherd Dog", "Rottweiler", "Beagle"], r["top3"])
check("sex never guessed", r["characteristics"]["sex"]["value"] == "Cannot determine from photograph")
check("AKC data attached", r["breed"]["group"] == "Herding Group" and r["breed"]["official_standard"]["coat"])
for code, fake, data in [
    ("not_a_dog", Fake(dets=[("cat", .98, (0, 0, 400, 400))]), None),
    ("not_a_dog", Fake(dets=[("person", .98, (0, 0, 400, 400))]), None),
    ("not_a_dog", Fake(dets=[]), None),
    ("dog_unclear", Fake(dets=[("dog", .55, (0, 0, 400, 400))]), None),
    ("multiple_dogs", Fake(dets=[("dog", .95, (0, 0, 300, 400)), ("dog", .92, (300, 0, 600, 400))], probs=GSD), None),
    ("too_blurry", Fake(probs=GSD), jpeg(flat=True)),
    ("too_dark", Fake(probs=GSD), jpeg(flat=True, value=5)),
    ("too_bright", Fake(probs=GSD), jpeg(flat=True, value=252)),
    ("too_small", Fake(probs=GSD), jpeg(size=(60, 60))),
    ("bad_image", Fake(probs=GSD), b"this is not an image"),
]:
    r = run(fake, data)
    check(f"rejected as {code}", r.get("code") == code, r)
r = run(Fake(dets=[("dog", .95, (0, 0, 400, 480)), ("dog", .9, (410, 0, 590, 300))], probs=GSD))
check("small second dog gives a warning", r["status"] == "ok" and any("largest" in w for w in r["warnings"]), r)
r = run(Fake(probs={"Beagle": .3, "Rottweiler": .28, "Pug": .22, "Boxer": .2}))
check("low score names no breed", r["verdict"] == "uncertain" and r["breed"] is None and r["mixed_possible"], r)
r = run(Fake(probs={"other_dog": .8, "Beagle": .2}))
check("other dog names no breed", r["verdict"] == "uncertain" and r["breed"] is None and r["mixed_possible"], r)
check("other_dog hidden from top 3", all(t["name"] != "other_dog" for t in r["top3"]), r["top3"])
r = run(Fake(probs={"Poodle (Toy)": .92, "Poodle (Miniature)": .05, "Beagle": .03}))
check("clear toy poodle", r["headline"] == "Poodle" and "Toy" in r["characteristics"]["variety"]["value"] and r["characteristics"]["size"]["value"] == "Toy", r)
r = run(Fake(probs={"Poodle (Toy)": .5, "Poodle (Miniature)": .45, "Beagle": .05}))
check("poodle size unclear", r["verdict"] == "confident" and r["headline"] == "Poodle" and r["characteristics"]["variety"]["value"] == "Size unclear from photo", r)
r = run(Fake(probs={"Poodle (Toy)": .92, "Poodle (Miniature)": .05, "Beagle": .03}, puppy=True))
check("puppy is not called miniature", r["characteristics"]["variety"]["value"] == "Not estimated for a puppy" and r["characteristics"]["size"]["value"] == "Depends on variety", r)
r = run(Fake(probs={"Miniature Schnauzer": .5, "Standard Schnauzer": .45, "Beagle": .05}))
check("schnauzer size unclear", r["headline"] == "Schnauzer" and r["characteristics"]["variety"]["value"] == "Size unclear from photo", r)
print("\nFAILED:", failures) if failures else print("\nAll checks passed.")
sys.exit(1 if failures else 0)
