# AI Dog Scanner

Upload one photo of a dog and get its likely breed, the top 3 matches, coat type and colour, size category, official AKC breed-standard details, and an age-based feeding plan.

![Home screen](docs/screenshots/home.png)

## Features

- **Breed identification** for 128 AKC-recognized breeds, with the top 3 matches and relative scores
- **Uncertainty handling:** says "Breed unclear" instead of guessing, and flags possible mixed breeds
- **Photo checks:** rejects cats, people, blurry, dark and multi-dog photos with a clear message
- **Size varieties:** Toy, Miniature and Standard Poodle; Miniature, Standard and Giant Schnauzer
- **Coat type and colour** read from the photo
- **AKC breed standards:** group, height, weight, coat, colours and temperament, with links to the official AKC documents
- **Diet plan** by age, weight and size: daily calories, meals per day, example schedule and foods to avoid
- **Report download** and a mobile-friendly layout

| Results | Diet plan | Mobile |
|---|---|---|
| ![Results](docs/screenshots/results.png) | ![Diet plan](docs/screenshots/diet-plan.png) | ![Mobile](docs/screenshots/mobile.png) |

*Screenshots use a placeholder image and test data to show the layout. They are not a real prediction.*

## How it works

```mermaid
flowchart LR
    subgraph FE[Frontend]
      A[Upload page<br/>HTML, CSS, JS]
    end
    subgraph BE[Backend]
      B[Java API<br/>Spring Boot]
      C[AI service<br/>Python FastAPI]
    end
    A -->|POST /api/scan| B
    B -->|REST| C
    C --> D[Dog detection<br/>DETR ResNet-50]
    D --> E[Photo checks<br/>blur, light, size]
    E --> F[Breed classifier<br/>128 breeds]
    E --> G[Coat and colour<br/>CLIP]
    F --> H[AKC breed database]
    G --> H
    H -->|JSON| B
    B -->|JSON| A
```

## Project structure

| Folder | Category | What it does |
|---|---|---|
| [`frontend/`](frontend) | Frontend | Upload page, results page, diet plan and report download |
| [`backend/java-api/`](backend/java-api) | Backend | Spring Boot API that serves the site and forwards scans to the AI service |
| [`backend/ai-service/`](backend/ai-service) | Backend | FastAPI service that runs the AI models and returns results as JSON |
| [`ml/notebook/`](ml/notebook) | Machine learning | Colab notebook that trains and tests the breed model |
| [`ml/data-tools/`](ml/data-tools) | Machine learning | Scripts that build the AKC breed database |
| [`claude-web-app/`](claude-web-app) | Extra | Single-page version that runs inside claude.ai |
| [`docs/`](docs) | Docs | Screenshots |

```
DOG-AI-SCANNER-TAILES/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   ├── app.js
│   └── fonts/
├── backend/
│   ├── java-api/
│   │   ├── pom.xml
│   │   └── src/main/java/com/dogscanner/
│   │       ├── DogScannerApplication.java
│   │       ├── ScanController.java
│   │       ├── AiServiceClient.java
│   │       ├── ScanValidator.java
│   │       └── UploadErrors.java
│   └── ai-service/
│       ├── main.py
│       ├── pipeline.py
│       ├── breed_db.py
│       ├── requirements.txt
│       ├── data/          (breeds.json, labels.json)
│       ├── model/         (trained model goes here)
│       └── tests/
├── ml/
│   ├── notebook/train_dog_scanner.ipynb
│   └── data-tools/
├── claude-web-app/
├── docs/screenshots/
├── START-HERE.html
└── start-windows.bat
```

## Tech stack

| Category | Technology |
|---|---|
| Frontend | HTML, CSS, JavaScript |
| Backend API | Java 17, Spring Boot 3 |
| AI service | Python 3.12, FastAPI, Uvicorn, PyTorch, Hugging Face Transformers, Pillow |
| Models | DETR ResNet-50 (dog detection), CLIP ViT-B/32 (coat), fine-tuned image classifier (breed) |
| Training | Google Colab notebook (free T4 GPU) |
| Data | JSON breed database built from AKC sources |

The notebook compares ConvNeXt V2, EfficientNet, ResNet, MobileNet and CLIP on the same photos, then trains the best one.

## API

| Endpoint | Served by | Purpose |
|---|---|---|
| `GET /api/health` | Java API | Reports whether the AI models are ready |
| `POST /api/scan` | Java API | Takes a photo (`file`, JPG/PNG/WebP, up to 10 MB) and returns the scan result |
| `GET /health`, `POST /scan` | AI service (port 8000) | Called by the Java API only |

## Run it

Full beginner steps are in [START-HERE.html](START-HERE.html). In short:

1. Install Python 3.12 and Java 17 or later.
2. Upload `ml/notebook/train_dog_scanner.ipynb` to Google Colab, choose a T4 GPU and click **Run all** (about 2 hours).
3. Unzip the trained `dog_model.zip` into `backend/ai-service/model/`.
4. On Windows, double-click `start-windows.bat`. The site opens at http://localhost:8080.

## Testing

| What | How | Status |
|---|---|---|
| Scanner decisions (rejections, uncertainty, Poodle and Schnauzer sizes, puppies) | `python backend/ai-service/tests/test_pipeline.py` | 22 checks passing |
| Website flows (upload, errors, results, report, mobile) | Browser tests | Passing |
| Breed accuracy | Notebook measures top-1 and top-3 on held-out test photos | Measured after training |
| Cats, people, blurry and two-dog photos | Notebook step 11 | Measured after training |

No accuracy figure is claimed until the model has been trained and tested.

## Limitations

- **Sex** always shows "Cannot determine from photograph". A normal photo can't show it reliably.
- **Coat and colour** come from a general vision model and haven't been accuracy-tested.
- **Size varieties** are visual estimates, because a photo doesn't show true height.
- **12 breeds** have about 35 training photos each, so expect weaker results for them.
- **Scores** are the model's relative output, not a guaranteed chance of being correct.
- Results are not an official AKC identification or conformation assessment.

## Data sources and credits

- [American Kennel Club](https://www.akc.org/): official breed standards and the breed weight chart
- [akcdata](https://github.com/tmfilho/akcdata): open copy of AKC breed page data
- [Tsinghua Dogs](https://cg.cs.tsinghua.edu.cn/ThuDogs/): Zou et al., "A new dataset of dog breed images and a benchmark for fine-grained classification", Computational Visual Media, 2020
- [Dog-Breeds-Dataset](https://github.com/AtharvaTaras/Dog-Breeds-Dataset) (CC-BY-4.0)
- Feeding guidance: AKC, Merck Veterinary Manual, VCA Animal Hospitals, ASPCA
